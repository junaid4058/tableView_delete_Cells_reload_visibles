//
//  NavigationViewController.swift
//  stackSwift
//
//  Created by Junaid's Mac Mini  on 5/24/17.
//  Copyright © 2017 Cuet. All rights reserved.
//

import UIKit

class NavigationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.changeNavBarColor() //NavigationBar UI change. custom function
        self.setNeedsStatusBarAppearanceUpdate() //This will call a function which will change the status bar color  white
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func changeNavBarColor() {
        self.navigationController?.navigationBar.barTintColor = UIColor.init(red: 49/255, green: 141/255, blue: 193/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName :UIColor.white]
        self.navigationController?.navigationBar.isTranslucent = false;
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    

}
