//
//  DeleteBtnTableViewController.swift
//  stackSwift
//
//  Created by Junaid's Mac Mini  on 5/26/17.
//  Copyright © 2017 Cuet. All rights reserved.
//

import UIKit

class DeleteBtnTableViewController:UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tableView: UITableView!
    
    var dataArray:[String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.makeData()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Table view data source

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataArray.count
    }


     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "customcell", for: indexPath) as! TableViewCell
        
        cell.cellLabel.text = dataArray[indexPath.row]
        cell.deleteBtn.tag = indexPath.row
        cell.deleteBtn.addTarget(self, action: #selector(onDeleteBtnPresed(sender :)), for:.touchUpInside)

        return cell
    }
    
    func onDeleteBtnPresed(sender : UIButton) {
        
        print(sender.tag)
        let indexpath = IndexPath.init(row: sender.tag, section: 0)

        tableView.beginUpdates()
        dataArray.remove(at: indexpath.row)
        tableView.deleteRows(at: [indexpath], with:.automatic)
        tableView.endUpdates()
        let when = DispatchTime.now() + 0.3 // change 2 to desired number of seconds
        DispatchQueue.main.asyncAfter(deadline: when) {
            self.tableView.reloadRows(at:self.tableView.indexPathsForVisibleRows!, with: .none)
        }
        
    }
    func makeData() {
        for i in 1..<101 {
            let data = "Data value" + String(i)
            dataArray.append(data)
        }
    }
    
}
