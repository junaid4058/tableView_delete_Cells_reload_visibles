import UIKit
class ViewController: UIViewController {

    let someView = UIView()
    var topValue:CGFloat = 10
    var verticalConstraint:NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        //This below codes are used to add a red color UIView in center which has width and height both 100
        someView.backgroundColor = UIColor.red
        someView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(someView)
        let horizontalConstraint = NSLayoutConstraint(item: someView, attribute: NSLayoutAttribute.centerX, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.centerX, multiplier: 1, constant: 0) //Center horizontally
        verticalConstraint = NSLayoutConstraint(item: someView, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.top, multiplier: 1, constant: topValue) // center vertically.want to change that constraint later so took a variable.
        let widthConstraint = NSLayoutConstraint(item: someView, attribute: NSLayoutAttribute.width, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1, constant: 100) //width 100
        let heightConstraint = NSLayoutConstraint(item: someView, attribute: NSLayoutAttribute.height, relatedBy: NSLayoutRelation.equal, toItem: nil, attribute: NSLayoutAttribute.notAnAttribute, multiplier: 1, constant: 100) //height 100
        view.addConstraints([horizontalConstraint, verticalConstraint, widthConstraint, heightConstraint])
        
    }
    
    @IBAction func updateView(_ sender: Any) {
        topValue += 10
        //In this case I've removed the previous constraint and add that constraint again with new Value
        self.view.removeConstraint(verticalConstraint)
         verticalConstraint = NSLayoutConstraint(item: someView, attribute: NSLayoutAttribute.top, relatedBy: NSLayoutRelation.equal, toItem: view, attribute: NSLayoutAttribute.top, multiplier: 1, constant: topValue)
        self.view.addConstraint(verticalConstraint)
        
        //In this case I've just update that constraint value.Commented because we are using first method
        //verticalConstraint.constant = topValue
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

